import os
import shutil
import hashlib

# Function to read paths from the configuration file
def get_paths_from_file(file_path):
    paths = []
    try:
        with open(file_path, "r") as file:
            paths = [line.strip() for line in file if line.strip()]  # Remove blank lines and strip whitespace
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' was not found.")
    return paths

# Function to calculate file checksum (SHA-256)
def calculate_checksum(file_path):
    hasher = hashlib.md5()  # Change SHA-256 to MD5
    try:
        with open(file_path, "rb") as f:
            while chunk := f.read(4096):
                hasher.update(chunk)
    except FileNotFoundError:
        return None
    return hasher.hexdigest()

# Function to create the .ftsinf file
def create_ftsinf(username, file_path):
    file_size = os.path.getsize(file_path)
    checksum = calculate_checksum(file_path)
    ftsinf_content = f"Username: {username}\nFilename: {os.path.basename(file_path)}\nSize: {file_size} bytes\nChecksum: {checksum}\n"
    
    ftsinf_path = file_path + ".ftsinf"  # Creating .ftsinf file next to the file
    with open(ftsinf_path, "w") as f:
        f.write(ftsinf_content)
    
    return ftsinf_path, checksum

# Function to read checksum from an existing .ftsinf file
def read_checksum_from_ftsinf(ftsinf_path):
    try:
        with open(ftsinf_path, "r") as f:
            for line in f:
                if line.startswith("Checksum:"):
                    return line.split("Checksum:")[1].strip()
    except FileNotFoundError:
        return None
    return None

# Main process
config_file = "D:\\Vaultify\\Main\\path.txt"
paths = get_paths_from_file(config_file)

if len(paths) >= 3:
    username = os.path.normpath(paths[0])  # Define your username here
    source_directory = os.path.normpath(paths[1])
    destination_directory = os.path.normpath(paths[2])
    archive_directory = os.path.normpath(paths[3])
    
    # Ensure destination and archive directories exist
    os.makedirs(destination_directory, exist_ok=True)
    os.makedirs(archive_directory, exist_ok=True)

    for file_name in os.listdir(source_directory):
        file_path = os.path.join(source_directory, file_name)

        if os.path.isfile(file_path):
            print(f"Processing file: {file_name}")

            # Step 1: Generate .ftsinf file
            ftsinf_path, original_checksum = create_ftsinf(username, file_path)

            # Step 2: Move both original file and .ftsinf file to Archive
            shutil.move(file_path, os.path.join(archive_directory, file_name))
            shutil.move(ftsinf_path, os.path.join(archive_directory, os.path.basename(ftsinf_path)))

            # Step 3: Recompute checksum in the Archive
            archived_file_path = os.path.join(archive_directory, file_name)
            archived_ftsinf_path = os.path.join(archive_directory, file_name + ".ftsinf")

            archived_checksum = calculate_checksum(archived_file_path)
            stored_checksum = read_checksum_from_ftsinf(archived_ftsinf_path)

            # Step 4: Compare checksums
            if archived_checksum == stored_checksum:
                print(f"Checksum match for {file_name}. Moving to respective extension folder.")

                # Determine file extension
                file_extension = os.path.splitext(file_name)[1][1:] or "no_extension"

                # Create extension-based folder if not exist
                extension_folder = os.path.join(destination_directory, file_extension)
                os.makedirs(extension_folder, exist_ok=True)

                # Move file to destination
                shutil.copy(archived_file_path, os.path.join(extension_folder, file_name))

            else:
                print(f"Checksum mismatch for {file_name}. Skipping file.")
else:
    print("Error: The 'path.txt' file must contain at least three lines: source, destination, and archive paths.")
